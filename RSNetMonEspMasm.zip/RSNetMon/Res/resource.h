//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDI_ICON_BOTH                   101
#define IDI_ICON_DISCONN                102
#define IDI_ICON_NONE                   103
#define IDI_ICON_RECEIVE                104
#define IDI_ICON_SEND                   105
#define IDI_ICON_DOWN_OFF               106
#define IDI_ICON_DOWN_ON                107
#define IDI_ICON_UP_OFF                 108
#define IDI_ICON_UP_ON                  109
#define IDI_ICON_DOWN_WHITE             110
#define IDI_ICON_UP_WHITE               111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
