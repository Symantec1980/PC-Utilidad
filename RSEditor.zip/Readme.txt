In the Release folder there is the Editor.exe file, which allows you
to test the RSEditor.dll. Just double-click on Editor.exe and try to
load text files, both ANSI and/or Unicode.

To open, edit and/or modified this project, download the Easy Code v2
application at http://www.easycode.cat
